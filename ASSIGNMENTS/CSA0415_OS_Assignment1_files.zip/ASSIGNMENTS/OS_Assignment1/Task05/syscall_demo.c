/* Task 05: a tiny program whose system calls we trace with strace.
   Compares direct system calls (open/read/write/close) with stdio (fopen/fread/fwrite). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main(void)
{
    const char *msg = "patient-record: ward=3 bed=17 hr=72\n";
    char buf[64];

    /* (a) direct system calls: one library wrapper -> one trap each */
    int fd = open("rec.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    write(fd, msg, strlen(msg));
    close(fd);

    fd = open("rec.txt", O_RDONLY);
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    buf[n] = '\0';
    write(STDOUT_FILENO, buf, (size_t)n);

    /* (b) stdio: fopen/fwrite/fread are buffered, fewer traps for many small calls */
    FILE *f = fopen("rec2.txt", "w");
    for (int i = 0; i < 100; i++) fputs("x", f);   /* 100 library calls */
    fclose(f);                                      /* one write() here */
    unlink("rec.txt");
    unlink("rec2.txt");
    return 0;
}
