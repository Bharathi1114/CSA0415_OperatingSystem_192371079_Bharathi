# Task 05 - System calls
Compile: gcc -std=c11 -Wall -Wextra -o syscall_demo syscall_demo.c
Run: ./syscall_demo ; strace -f -o strace_full.txt ./syscall_demo ; strace -c ./syscall_demo
Files: strace_full.txt (whole trace), strace_filtered.txt (relevant lines), strace_summary.txt (-c table).
