/* Task 10: time to create 1000 processes (fork) versus 1000 threads (pthread_create). */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/resource.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void *work(void *a){ (void)a; return NULL; }
int main(void)
{
    const int N = 1000;
    /* give the parent a realistic 50 MB heap so fork's page-table copy is visible */
    char *heap = malloc(50u << 20); for (size_t i = 0; i < (50u << 20); i += 4096) heap[i] = 1;

    double t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p = fork();
        if (p == 0) _exit(0);
        waitpid(p, NULL, 0);
    }
    double t1 = now();

    pthread_t th[N];
    double t2 = now();
    for (int i = 0; i < N; i++) { pthread_create(&th[i], NULL, work, NULL); pthread_join(th[i], NULL); }
    double t3 = now();

    printf("fork   : %d processes in %.4f s (%.1f us each)\n", N, t1 - t0, (t1 - t0) / N * 1e6);
    printf("pthread: %d threads   in %.4f s (%.1f us each)\n", N, t3 - t2, (t3 - t2) / N * 1e6);
    printf("ratio fork/thread = %.1fx\n", (t1 - t0) / (t3 - t2));
    free(heap);
    return 0;
}
