# Task 10 - Measure and compare
Run: bash run_all.sh. Result files: output.txt, output_run2.txt (fork vs pthread, 1000 each); ../Task06/strace_compare.txt, time_output.txt, bench_output.txt.
