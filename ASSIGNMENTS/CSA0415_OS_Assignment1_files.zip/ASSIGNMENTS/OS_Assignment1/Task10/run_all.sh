#!/bin/bash
# Task 10: reproduce every measurement. Needs gcc, strace.  Run from this folder: bash run_all.sh
set -e
CF="-std=c11 -Wall -Wextra -pthread"
gcc $CF -o ../Task06/copy_one ../Task06/copy_one.c
gcc $CF -O1 -o ../Task06/copy_big ../Task06/copy_big.c
gcc $CF -o bench_fork_thread bench_fork_thread.c
cd ../Task06
for b in 1 512 4096; do strace -c -e trace=read,write ./copy_one $b; done
bash time_cmp.sh
cd ../Task10 && ./bench_fork_thread
