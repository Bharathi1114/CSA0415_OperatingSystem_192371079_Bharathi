#!/bin/bash
# Task 03: show evidence of the structure of the running Linux kernel (monolithic + loadable modules).
echo "== kernel =="; uname -srm
echo "== number of loaded kernel modules =="; (lsmod 2>/dev/null | tail -n +2 | wc -l) || echo "lsmod unavailable"
echo "== sample of modules =="; lsmod 2>/dev/null | head -5
echo "== kernel config (modular vs built-in) =="
grep -E "CONFIG_MODULES=|CONFIG_PREEMPT" /boot/config-$(uname -r) 2>/dev/null || zcat /proc/config.gz 2>/dev/null | grep -E "CONFIG_MODULES=|CONFIG_PREEMPT" || echo "(config not exposed in this environment)"
