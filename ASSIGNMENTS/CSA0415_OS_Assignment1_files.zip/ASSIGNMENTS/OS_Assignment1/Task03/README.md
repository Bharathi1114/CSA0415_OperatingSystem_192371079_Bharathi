# Task 03 - OS structures
Run: bash kernel_structure.sh (output.txt) shows the running kernel and its loadable modules. Structure comparison and the monolithic-vs-microkernel analysis are in the report (Task 3).
