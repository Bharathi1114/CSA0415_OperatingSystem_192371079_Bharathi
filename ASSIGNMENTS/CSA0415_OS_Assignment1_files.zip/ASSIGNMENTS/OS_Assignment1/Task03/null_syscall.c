/* Task 03: measure the cost of one trivial system call (getpid through syscall()). */
#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <time.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void noop(void){ __asm__ volatile("" ::: "memory"); }
int main(void)
{
    long N = 5000000; double t0 = now();
    for (long i = 0; i < N; i++) syscall(SYS_getpid);
    double t1 = now();
    for (long i = 0; i < N; i++) noop();
    double t2 = now();
    printf("null system call : %.1f ns each\n", (t1 - t0) / N * 1e9);
    printf("plain function   : %.2f ns each\n", (t2 - t1) / N * 1e9);
    return 0;
}
