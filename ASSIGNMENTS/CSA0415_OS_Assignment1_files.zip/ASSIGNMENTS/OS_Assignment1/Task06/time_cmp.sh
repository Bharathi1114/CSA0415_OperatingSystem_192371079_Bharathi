#!/bin/bash
# Task 10: user/sys time of the copy for different buffer sizes (uses copy_bench-style single run)
head -c 2000000 /dev/urandom > big.dat
for b in 1 512 4096 65536; do
  echo "--- buffer $b ---"
  ( TIMEFORMAT='real %3R  user %3U  sys %3S'; time ./copy_big $b big.dat big.copy )
done
rm -f big.dat big.copy
