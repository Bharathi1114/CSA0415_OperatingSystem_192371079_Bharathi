/* Task 06 driver: reuse copy_file() from copy_syscalls.c for ONE buffer size given on the command line,
   so strace -c can be run separately for each buffer size. */
#define main orig_main
#include "copy_syscalls.c"
#undef main
#include <stdlib.h>
int main(int argc, char **argv)
{
    size_t b = argc > 1 ? (size_t)atol(argv[1]) : 4096;
    FILE *f = fopen("records.dat", "w");
    for (int i = 0; i < 10000; i++) fputc('A' + i % 26, f);
    fclose(f);
    long calls = copy_file("records.dat", "copy.dat", b);
    unlink("records.dat"); unlink("copy.dat");
    fprintf(stderr, "buffer %zu: program counted %ld read() calls\n", b, calls);
    return 0;
}
