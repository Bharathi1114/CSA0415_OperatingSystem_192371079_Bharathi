/* Task 06 alternative: copy with memory-mapped files (mmap) - few system calls. */
#define _GNU_SOURCE
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s src dst\n", argv[0]); return 1; }
    int in = open(argv[1], O_RDONLY);
    int out = open(argv[2], O_RDWR | O_CREAT | O_TRUNC, 0644);
    struct stat st; fstat(in, &st);
    ftruncate(out, st.st_size);
    char *s = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, in, 0);
    char *d = mmap(NULL, st.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, out, 0);
    memcpy(d, s, st.st_size);
    munmap(s, st.st_size); munmap(d, st.st_size);
    close(in); close(out);
    return 0;
}
