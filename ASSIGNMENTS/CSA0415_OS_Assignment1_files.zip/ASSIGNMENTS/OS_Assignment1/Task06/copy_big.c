/* usage: copy_big <bufsize> <src> <dst> -- plain read()/write() copy used for the `time` experiment */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char **argv)
{
    if (argc < 4) return 1;
    size_t b = (size_t)atol(argv[1]); char *buf = malloc(b); ssize_t n;
    int in = open(argv[2], O_RDONLY), out = open(argv[3], O_WRONLY|O_CREAT|O_TRUNC, 0644);
    while ((n = read(in, buf, b)) > 0) if (write(out, buf, (size_t)n) < 0) break;
    close(in); close(out); free(buf); return 0;
}
