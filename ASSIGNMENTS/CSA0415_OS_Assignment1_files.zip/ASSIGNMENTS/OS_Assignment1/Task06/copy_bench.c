/* Task 06/10: time read()/write() copy of a large file for several buffer sizes. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
int main(int argc, char **argv)
{
    const char *src = argc > 1 ? argv[1] : "big.dat";
    size_t sizes[] = {1, 16, 64, 512, 4096, 65536, 1048576};
    printf("%10s %12s %10s\n", "buffer(B)", "read()calls", "time(s)");
    for (int i = 0; i < 7; i++) {
        size_t b = sizes[i];
        char *buf = malloc(b);
        int in = open(src, O_RDONLY), out = open("big.copy", O_WRONLY|O_CREAT|O_TRUNC, 0644);
        long calls = 0; ssize_t n; double t0 = now();
        while ((n = read(in, buf, b)) > 0) { calls++; if (write(out, buf, (size_t)n) < 0) break; }
        double t1 = now();
        close(in); close(out); free(buf);
        printf("%10zu %12ld %10.4f\n", b, calls, t1 - t0);
    }
    unlink("big.copy");
    return 0;
}
