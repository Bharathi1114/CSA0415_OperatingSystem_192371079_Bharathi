# Task 06 - Cost of system calls
Compile: gcc -std=c11 -Wall -Wextra -o copy_syscalls copy_syscalls.c  (also copy_one.c, copy_bench.c, copy_big.c, copy_stdio.c, copy_mmap.c)
Result: output.txt matches the expected output (10001 / 21 / 4 read() calls). strace_compare.txt shows strace sees exactly +1 read (the dynamic loader). bench_output.txt and time_output.txt hold timings for a 2 MB file.
