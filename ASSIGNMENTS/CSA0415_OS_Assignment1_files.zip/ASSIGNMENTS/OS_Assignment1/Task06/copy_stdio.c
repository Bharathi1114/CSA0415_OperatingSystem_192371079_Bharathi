/* Task 06 alternative: copy with fopen/fread/fwrite (library buffering, default 4096). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "usage: %s src dst chunk\n", argv[0]); return 1; }
    size_t chunk = (size_t)atol(argv[3]);
    char *buf = malloc(chunk);
    FILE *in = fopen(argv[1], "rb"), *out = fopen(argv[2], "wb");
    size_t n;
    while ((n = fread(buf, 1, chunk, in)) > 0) fwrite(buf, 1, n, out);
    fclose(in); fclose(out); free(buf);
    return 0;
}
