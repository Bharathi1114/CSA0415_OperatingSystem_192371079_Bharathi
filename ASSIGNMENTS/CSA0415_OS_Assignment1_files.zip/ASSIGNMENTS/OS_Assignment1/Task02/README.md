# Task 02 - Type of OS per environment
Theory task. Decision: monitors = hard real-time OS; tablets = handheld OS; workstations = desktop OS; database server = clustered with fail-over; imaging server = SMP; partner link = distributed. Full comparison and rejected alternatives are in the report (Task 2).
