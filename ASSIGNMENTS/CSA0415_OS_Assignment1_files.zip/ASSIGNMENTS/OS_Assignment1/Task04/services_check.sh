#!/bin/bash
# Task 04: demonstrate OS services in use on Linux.
echo "== program execution (process list, top 3) =="; ps -eo pid,comm | head -4
echo "== file system service =="; df -h / | tail -1; ls -l /etc/hostname
echo "== protection (owner/permissions of a private file) =="
umask 077; echo secret > /tmp/patient.txt; ls -l /tmp/patient.txt
id
echo "== error detection (open of missing file returns error from kernel) =="
cat /nonexistent 2>&1 | head -1
echo "== accounting (CPU time used by this shell) =="; times
echo "== resource allocation (memory) =="; free -m | head -2
rm -f /tmp/patient.txt
