# Task 04 - OS services
Run: bash services_check.sh (output.txt) demonstrates program execution, file system, protection, error detection, accounting and resource allocation on Linux. Service table is in the report (Task 4).
