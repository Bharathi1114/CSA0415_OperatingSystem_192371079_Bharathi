/* Task 07: demonstrate a zombie (child exited, parent has not wait()ed) and an orphan. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void)
{
    pid_t z = fork();
    if (z == 0) _exit(0);                           /* child exits at once */
    sleep(1);                                       /* parent has not waited -> zombie */
    char cmd[64];
    snprintf(cmd, sizeof cmd, "ps -o pid,ppid,stat,comm -p %d", (int)z);
    printf("--- zombie child (STAT Z) ---\n"); fflush(stdout);
    system(cmd);
    waitpid(z, NULL, 0);                            /* reap: zombie disappears */

    pid_t o = fork();
    if (o == 0) {                                   /* child outlives parent */
        sleep(1);
        printf("--- orphan: my parent is now pid %d (was re-parented to init/subreaper) ---\n", (int)getppid());
        return 0;
    }
    return 0;                                       /* parent exits first */
}
