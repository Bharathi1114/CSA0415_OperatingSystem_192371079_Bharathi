/* Task 07 alternative: start 1000 commands with fork+exec versus posix_spawn. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <spawn.h>
#include <time.h>
#include <sys/wait.h>
extern char **environ;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
int main(void)
{
    int N = 1000, st;
    double t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p = fork();
        if (p == 0) { execl("/bin/true", "true", (char *)NULL); _exit(127); }
        waitpid(p, &st, 0);
    }
    double t1 = now();
    for (int i = 0; i < N; i++) {
        pid_t p; char *argv[] = {"true", NULL};
        posix_spawn(&p, "/bin/true", NULL, NULL, argv, environ);
        waitpid(p, &st, 0);
    }
    double t2 = now();
    printf("fork+exec  : %d commands in %.3f s (%.1f us each)\n", N, t1-t0, (t1-t0)/N*1e6);
    printf("posix_spawn: %d commands in %.3f s (%.1f us each)\n", N, t2-t1, (t2-t1)/N*1e6);
    return 0;
}
