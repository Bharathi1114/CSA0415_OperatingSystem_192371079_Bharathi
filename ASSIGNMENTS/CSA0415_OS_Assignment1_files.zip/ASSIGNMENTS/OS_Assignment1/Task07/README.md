# Task 07 - Process control
Compile: gcc -std=c11 -Wall -Wextra -o shell shell.c
Result: output.txt matches the expected output. shell_noflush.c + redirect_noflush.txt show the duplicated lines when stdout is not flushed before fork() and exit(3) is used. zombie_orphan.c, spawn_vs_fork.c and strace_shell.txt are extra evidence.
