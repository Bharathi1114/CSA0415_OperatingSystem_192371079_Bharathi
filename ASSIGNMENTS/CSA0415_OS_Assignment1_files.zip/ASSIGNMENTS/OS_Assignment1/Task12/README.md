# Task 12 - Design challenge (home monitors and cloud records)
Impact analysis, evaluation of the original design, revised design and the evidence-based defence are in the report (Task 12). Decision: MODIFY - keep the hospital core, add an RTOS on home devices, a gateway, and a replicated cloud record service.
