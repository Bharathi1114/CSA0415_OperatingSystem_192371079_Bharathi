# Task 01 - Requirements of each environment
Run: python3 requirements_rank.py (output in output.txt). Ranked requirement table and justification are in the report (Task 1). Result: bedside monitors rank response time and reliability first; tablets rank battery first; servers rank reliability/throughput/security.
