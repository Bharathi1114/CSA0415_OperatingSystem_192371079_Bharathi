#!/usr/bin/env python3
"""Task 01: weighted ranking of requirements for each hospital environment.
Scores are 1-5 (5 = most critical); weights reflect patient-safety priority.
Run: python3 requirements_rank.py"""
envs = {
 "Bedside monitor":   {"Response time":5,"Reliability":5,"Throughput":1,"Battery/power":3,"Security":3},
 "Nurse tablet":      {"Response time":3,"Reliability":3,"Throughput":1,"Battery/power":5,"Security":4},
 "Doctor workstation":{"Response time":3,"Reliability":3,"Throughput":2,"Battery/power":1,"Security":5},
 "Database server":   {"Response time":3,"Reliability":5,"Throughput":4,"Battery/power":1,"Security":5},
 "Imaging server":    {"Response time":2,"Reliability":3,"Throughput":5,"Battery/power":1,"Security":4},
 "Partner link":      {"Response time":2,"Reliability":4,"Throughput":3,"Battery/power":1,"Security":5},
}
for e, req in envs.items():
    print(f"\n{e}")
    for rank,(k,v) in enumerate(sorted(req.items(), key=lambda x:-x[1]),1):
        print(f"  {rank}. {k:15s} score {v}")
