/* Task 09: measure access time per level of the memory hierarchy with pointer chasing.
   Working-set sizes from 4 KB (L1) up to 256 MB (main memory). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
int main(void)
{
    size_t kb[] = {4, 16, 32, 128, 512, 2048, 8192, 32768, 262144};
    printf("%10s %12s\n", "size(KB)", "ns/access");
    for (int s = 0; s < 9; s++) {
        size_t n = kb[s] * 1024 / sizeof(size_t);
        size_t *a = malloc(n * sizeof(size_t));
        size_t *idx = malloc(n * sizeof(size_t));
        for (size_t i = 0; i < n; i++) idx[i] = i;
        srand(1);
        for (size_t i = n - 1; i > 0; i--) { size_t j = (size_t)rand() % (i + 1); size_t t = idx[i]; idx[i] = idx[j]; idx[j] = t; }
        for (size_t i = 0; i < n; i++) a[idx[i]] = idx[(i + 1) % n];   /* one random cycle */
        size_t p = idx[0]; long steps = 20000000;
        for (long i = 0; i < 1000000; i++) p = a[p];                    /* warm up */
        double t0 = now();
        for (long i = 0; i < steps; i++) p = a[p];
        double t1 = now();
        printf("%10zu %12.2f%s\n", kb[s], (t1 - t0) / steps * 1e9, p == (size_t)-1 ? "!" : "");
        free(a); free(idx);
    }
    return 0;
}
