# Task 09 - Memory hierarchy and I/O
Compile: gcc -std=c11 -O1 -o mem_latency mem_latency.c ; python3 io_methods.py
Result: output.txt shows latency rising from about 1.7 ns (L1) to about 186 ns (main memory). io_output.txt compares interrupt-per-word and DMA for a 500 MB image.
