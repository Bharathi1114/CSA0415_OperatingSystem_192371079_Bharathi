#!/usr/bin/env python3
"""Task 09 alternative-concept calculation: 500 MB MRI image, interrupt per word vs DMA.
Assumptions (stated): 32-bit word, 2 us CPU cost per interrupt (handler + context switch),
DMA block size 4 KB with one interrupt per block."""
size = 500 * 1024 * 1024
word = 4
irq_cost = 2e-6
words = size // word
print(f"words in 500 MB image           : {words:,}")
print(f"interrupt-per-word interrupts   : {words:,}")
print(f"interrupt-per-word CPU time     : {words*irq_cost:.1f} s")
blocks = size // 4096
print(f"DMA interrupts (4 KB blocks)    : {blocks:,}")
print(f"DMA CPU time                    : {blocks*irq_cost:.2f} s")
print(f"reduction in interrupts         : {words/blocks:.0f}x")
print("buffer needed: interrupt-per-word 4 bytes; DMA 4 KB-1 MB buffer (double-buffered 2x)")
