/* Task 08: polling versus interrupt-style (blocking) detection of an abnormal reading.
   A "sensor" process writes a byte to a pipe after 300 ms. The monitor either
   (a) polls the pipe in a loop, or (b) blocks in read() until the kernel wakes it. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/resource.h>
#include <sys/wait.h>
static void usleep_us(long us){struct timespec t={us/1000000,(us%1000000)*1000};nanosleep(&t,NULL);}
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static double cpu(void){struct rusage r;getrusage(RUSAGE_SELF,&r);return r.ru_utime.tv_sec+r.ru_stime.tv_sec+(r.ru_utime.tv_usec+r.ru_stime.tv_usec)/1e6;}

static void run(int polling, int interval_us)
{
    int p[2]; pipe(p);
    pid_t c = fork();
    if (c == 0) {                               /* sensor */
        usleep_us(300000);
        char x = 'A'; write(p[1], &x, 1); _exit(0);
    }
    double t0 = now(), c0 = cpu(); char x; ssize_t n;
    if (polling) {
        fcntl(p[0], F_SETFL, O_NONBLOCK);
        while ((n = read(p[0], &x, 1)) < 0) { if (interval_us) usleep_us(interval_us); }
    } else {
        n = read(p[0], &x, 1);                  /* sleeps; woken by kernel when data arrives */
    }
    double t1 = now(), c1 = cpu();
    waitpid(c, NULL, 0);
    printf("%-22s detected after %.4f s, CPU used %.4f s\n",
           polling ? (interval_us ? "polling (sleep 10ms)" : "polling (busy loop)") : "blocking/interrupt",
           t1 - t0, c1 - c0);
    (void)n;
}
int main(void)
{
    run(1, 0);       /* busy polling   */
    run(1, 10000);   /* polling every 10 ms */
    run(0, 0);       /* interrupt-driven (blocking) */
    return 0;
}
