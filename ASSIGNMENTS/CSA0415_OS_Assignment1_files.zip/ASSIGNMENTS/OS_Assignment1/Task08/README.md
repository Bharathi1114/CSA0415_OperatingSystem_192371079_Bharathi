# Task 08 - CPU states and protection
Compile: gcc -std=c11 -Wall -Wextra -o poll_vs_interrupt poll_vs_interrupt.c
Result (output.txt): busy polling burns about 100% CPU while waiting; blocking read (interrupt-style wake-up) uses about 0 CPU and notices the event as fast or faster.
