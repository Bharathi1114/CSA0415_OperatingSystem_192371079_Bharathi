# CSA0415 Operating Systems - Assignment 1 (Smart Hospital OS Design)

- Name: Bharathi
- Register number: 192371079
- Course: CSA0415 Operating Systems, SIMATS Engineering
- Compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0
- Linux: Ubuntu 24.04.5 LTS, kernel 6.18.44 (1 vCPU virtual machine)
- strace 6.8
- Compile command used for every program: `gcc -std=c11 -Wall -Wextra -pthread -o <name> <name>.c`
  (`copy_mmap.c` uses `-std=gnu11`; `bench_fork_thread.c` uses `-std=gnu11 -pthread`)

## Folder layout
`ASSIGNMENTS/OS_Assignment1/Task01 ... Task12`, each with source code, outputs, and a short README.

## How to run each program
| Task | Command | Result |
|---|---|---|
| 01 | `python3 Task01/requirements_rank.py` | ranked requirement table |
| 03 | `bash Task03/kernel_structure.sh` | kernel and module evidence |
| 04 | `bash Task04/services_check.sh` | OS services demo |
| 05 | `cd Task05 && gcc -std=c11 -o syscall_demo syscall_demo.c && strace -f ./syscall_demo` | system call trace |
| 06 | `cd Task06 && gcc -std=c11 -o copy_syscalls copy_syscalls.c && ./copy_syscalls` | 10001 / 21 / 4 read() calls (matches expected) |
| 07 | `cd Task07 && gcc -std=c11 -o shell shell.c && ./shell` | job 1 exit status 0, job 2 exit status 3 |
| 08 | `cd Task08 && gcc -std=c11 -o poll_vs_interrupt poll_vs_interrupt.c && ./poll_vs_interrupt` | polling vs blocking CPU use |
| 09 | `cd Task09 && gcc -O1 -o mem_latency mem_latency.c && ./mem_latency` | latency per hierarchy level |
| 10 | `cd Task10 && bash run_all.sh` | strace counts, time, fork vs thread |

Tasks 02, 11 and 12 are design/evaluation tasks answered in the report; their folders hold a short README.

## Notes
- Screenshots in each `screenshots/` folder are rendered from the captured terminal output files next to them.
- Timing numbers depend on the machine; re-run on your own Linux system to compare.
