/* Q1: cost of 2,000 concurrent sessions as processes versus threads.
   usage: proc_scale proc|thread N
   Measures creation time, memory (PSS for processes, VmRSS delta for threads). */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <time.h>
#include <sys/wait.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static long vmrss_kb(void){FILE*f=fopen("/proc/self/status","r");char l[256];long v=0;while(fgets(l,sizeof l,f))if(!strncmp(l,"VmRSS:",6))sscanf(l+6,"%ld",&v);fclose(f);return v;}
static long pss_kb(pid_t p){char path[64],l[256];long v=0;snprintf(path,sizeof path,"/proc/%d/smaps_rollup",(int)p);FILE*f=fopen(path,"r");if(!f)return 0;while(fgets(l,sizeof l,f))if(!strncmp(l,"Pss:",4)){sscanf(l+4,"%ld",&v);break;}fclose(f);return v;}
static volatile int stop_flag;
static void *session(void *a){(void)a;while(!stop_flag)usleep(100000);return NULL;}
int main(int argc,char**argv)
{
    int n = argc>2?atoi(argv[2]):2000; int proc = argc>1 && !strcmp(argv[1],"proc");
    char *session_data = malloc(64*1024); memset(session_data,1,64*1024);   /* 64 KB of per-session state */
    long base = vmrss_kb(); double t0 = now();
    if (proc) {
        pid_t *k = malloc(n*sizeof(pid_t)); int made = 0;
        for (int i=0;i<n;i++){ pid_t p=fork(); if(p==0){ session_data[0]++; for(;;)pause(); } if(p<0)break; k[made++]=p; }
        double t1 = now(); usleep(500000);
        long tot=0; for(int i=0;i<made;i++) tot+=pss_kb(k[i]);
        printf("processes: created %d in %.3f s (%.1f us each)\n", made, t1-t0, (t1-t0)/made*1e6);
        printf("processes: total PSS %ld KB = %.1f KB per session (parent RSS %ld KB)\n", tot, (double)tot/made, vmrss_kb());
        for(int i=0;i<made;i++)kill(k[i],SIGKILL); for(int i=0;i<made;i++)waitpid(k[i],NULL,0);
    } else {
        pthread_t *t = malloc(n*sizeof(pthread_t)); int made=0; pthread_attr_t at; pthread_attr_init(&at);
        for(int i=0;i<n;i++){ if(pthread_create(&t[made],&at,session,NULL))break; made++; }
        double t1 = now(); usleep(500000);
        long grown = vmrss_kb()-base;
        printf("threads  : created %d in %.3f s (%.1f us each)\n", made, t1-t0, (t1-t0)/made*1e6);
        printf("threads  : RSS growth %ld KB = %.1f KB per session\n", grown, (double)grown/made);
        stop_flag=1; for(int i=0;i<made;i++)pthread_join(t[i],NULL);
    }
    return 0;
}
