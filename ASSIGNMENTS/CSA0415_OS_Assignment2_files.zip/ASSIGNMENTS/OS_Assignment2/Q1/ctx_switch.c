/* Q1: measure context-switch cost by pipe ping-pong between two processes and between two threads.
   Both are pinned to one CPU so every message forces a switch. One round trip = 2 context switches. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <pthread.h>
#include <time.h>
#include <sys/wait.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static int a[2], b[2]; static const int N = 200000;
static void pin(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof s,&s);}
static void *echo(void *x){(void)x;char c;for(int i=0;i<N;i++){if(read(a[0],&c,1)<1)break;if(write(b[1],&c,1)<1)break;}return NULL;}
static double pingpong(void){char c='x';double t0=now();for(int i=0;i<N;i++){if(write(a[1],&c,1)<1)break;if(read(b[0],&c,1)<1)break;}return (now()-t0)/(2.0*N)*1e6;}
int main(void)
{
    pin();
    pipe(a); pipe(b);
    pid_t p = fork();
    if (p == 0) { echo(NULL); _exit(0); }
    double us_proc = pingpong(); waitpid(p, NULL, 0);
    close(a[0]);close(a[1]);close(b[0]);close(b[1]);
    pipe(a); pipe(b);
    pthread_t t; pthread_create(&t, NULL, echo, NULL);
    double us_thr = pingpong(); pthread_join(t, NULL);
    printf("process-to-process switch : %.2f us per switch (includes pipe read/write)\n", us_proc);
    printf("thread-to-thread switch   : %.2f us per switch (includes pipe read/write)\n", us_thr);
    return 0;
}
