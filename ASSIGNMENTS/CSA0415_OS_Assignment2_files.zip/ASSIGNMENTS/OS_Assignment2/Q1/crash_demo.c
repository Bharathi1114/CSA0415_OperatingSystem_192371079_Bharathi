/* Q1 alternative: effect of one crashing session. usage: crash_demo proc|thread */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
static void *bad_thread(void *a){(void)a; volatile int *p = NULL; *p = 1; return NULL;}
int main(int argc, char **argv)
{
    int use_proc = argc > 1 && !strcmp(argv[1], "proc");
    printf("server: serving sessions as %s\n", use_proc ? "PROCESSES" : "THREADS"); fflush(stdout);
    if (use_proc) {
        pid_t p = fork();
        if (p == 0) { volatile int *q = NULL; *q = 1; _exit(0); }   /* session crashes */
        int st; waitpid(p, &st, 0);
        if (WIFSIGNALED(st)) printf("server: session %d killed by signal %d (SIGSEGV), other sessions unaffected\n", (int)p, WTERMSIG(st));
        printf("server: still running and serving the other sessions\n");
    } else {
        pthread_t t; pthread_create(&t, NULL, bad_thread, NULL);
        pthread_join(t, NULL);
        printf("server: still running\n");                           /* never printed */
    }
    return 0;
}
