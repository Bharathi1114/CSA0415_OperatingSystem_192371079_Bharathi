/* Q1: create child processes with fork() and observe them with ps and /proc.
   Children are put into different states: R (busy), S (sleeping/waiting), D/S (I/O wait on a pipe),
   Z (zombie: exited, parent has not wait()ed), T (stopped). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <time.h>

static void spin_ms(int ms){struct timespec t0,t;clock_gettime(CLOCK_MONOTONIC,&t0);do{clock_gettime(CLOCK_MONOTONIC,&t);}while((t.tv_sec-t0.tv_sec)*1000+(t.tv_nsec-t0.tv_nsec)/1000000<ms);}

int main(void)
{
    int fd[2]; if (pipe(fd) < 0) return 1;
    pid_t kid[5];
    for (int i = 0; i < 5; i++) {
        kid[i] = fork();
        if (kid[i] == 0) {
            if (i == 0) { for (;;) spin_ms(100); }          /* RUNNING / READY: uses the CPU */
            if (i == 1) { sleep(30); _exit(0); }             /* WAITING: timer sleep */
            if (i == 2) { char c; close(fd[1]); read(fd[0], &c, 1); _exit(0); } /* WAITING: blocked on I/O (pipe) */
            if (i == 3) { _exit(0); }                        /* TERMINATED but not reaped: zombie */
            if (i == 4) { raise(SIGSTOP); _exit(0); }        /* stopped */
        }
    }
    sleep(1);
    printf("parent pid %d, children:", (int)getpid());
    for (int i = 0; i < 5; i++) printf(" %d", (int)kid[i]);
    printf("\n\n$ ps -o pid,ppid,stat,wchan:14,comm --ppid %d\n", (int)getpid()); fflush(stdout);
    char cmd[256];
    snprintf(cmd, sizeof cmd, "ps -o pid,ppid,stat,wchan:14,comm --ppid %d", (int)getpid()); system(cmd);
    for (int i = 0; i < 5; i++) {
        printf("\n$ grep -E 'Name|State|Pid|PPid|VmRSS|ctxt' /proc/%d/status   (child %d)\n", (int)kid[i], i); fflush(stdout);
        snprintf(cmd, sizeof cmd, "grep -E 'Name|State|^Pid|PPid|VmRSS|ctxt' /proc/%d/status", (int)kid[i]); system(cmd);
    }
    printf("\n$ cat /proc/%d/stat | cut -d' ' -f1-4,14-15,20\n", (int)kid[0]); fflush(stdout);
    snprintf(cmd, sizeof cmd, "cut -d' ' -f1-4,14-15,20 /proc/%d/stat", (int)kid[0]); system(cmd);
    for (int i = 0; i < 5; i++) { kill(kid[i], SIGKILL); }
    for (int i = 0; i < 5; i++) waitpid(kid[i], NULL, 0);
    return 0;
}
