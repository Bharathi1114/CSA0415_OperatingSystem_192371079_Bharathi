# Q1 - Processes and process states
Build: gcc -std=gnu11 -O1 -Wall -Wextra -pthread -o fork_states fork_states.c (same for proc_scale, ctx_switch, crash_demo)
Run: ./fork_states (ps and /proc evidence) ; ./proc_scale proc 2000 ; ./proc_scale thread 2000 ; ./ctx_switch ; ./crash_demo proc ; ./crash_demo thread
Result: children shown in R, S (timer), S (pipe I/O), Z and T states; 2000 processes cost 28.0 KB each (PSS), 2000 threads 8.4 KB each; crash isolation shown. State diagram and PCB description are in the report.
