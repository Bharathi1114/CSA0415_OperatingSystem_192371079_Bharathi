/* Q5: dining philosophers with semaphores. usage: philosophers safe | naive
   safe  : a counting semaphore "room" admits at most 4 philosophers, so a circular wait is impossible
   naive : everybody takes the left fork then the right fork; with a pause between the two it deadlocks (detected by alarm). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#define N 5
#define MEALS 1000
static sem_t fork_s[N], room; static int naive; static long meals[N];
static void pause_us(long us){ struct timespec t = {0, us * 1000}; nanosleep(&t, NULL); }
static void *phil(void *a){ int i = (int)(long)a; int l = i, r = (i + 1) % N;
    for (int m = 0; m < MEALS; m++) {
        if (!naive) sem_wait(&room);
        sem_wait(&fork_s[l]); if (naive) pause_us(1000); sem_wait(&fork_s[r]);
        meals[i]++;                                           /* eat */
        sem_post(&fork_s[r]); sem_post(&fork_s[l]);
        if (!naive) sem_post(&room);
    } return NULL; }
static void on_alarm(int s){ (void)s; printf("naive: DEADLOCK - no philosopher can proceed. meals so far:"); for (int i = 0; i < N; i++) printf(" %ld", meals[i]); printf("\n"); fflush(stdout); _exit(0); }
int main(int argc, char **argv){ naive = argc > 1 && !strcmp(argv[1], "naive");
    for (int i = 0; i < N; i++) sem_init(&fork_s[i], 0, 1); sem_init(&room, 0, N - 1);
    signal(SIGALRM, on_alarm); alarm(3);
    pthread_t t[N]; for (long i = 0; i < N; i++) pthread_create(&t[i], NULL, phil, (void *)i);
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    printf("safe: all philosophers finished; meals eaten:"); for (int i = 0; i < N; i++) printf(" %ld", meals[i]); printf(" (each expected %d)\n", MEALS); return 0; }
