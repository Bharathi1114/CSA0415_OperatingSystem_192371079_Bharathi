/* Q5 alternative: protect a shared counter with atomic add, spin lock, mutex or semaphore.
   usage: counter_bench <threads> <updates each> <cs_ns>   (cs_ns: extra busy work inside the critical section)
   Prints wall time per update and total CPU time (user+sys), so CPU wasted by spinning is visible. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdatomic.h>
#include <time.h>
#include <sys/resource.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static double cpu(void){struct rusage r;getrusage(RUSAGE_SELF,&r);return r.ru_utime.tv_sec+r.ru_stime.tv_sec+(r.ru_utime.tv_usec+r.ru_stime.tv_usec)/1e6;}
static long counter; static atomic_long acounter; static atomic_flag spin = ATOMIC_FLAG_INIT; static pthread_mutex_t mx = PTHREAD_MUTEX_INITIALIZER; static sem_t sm;
static long N, cs_ns; static int kind;
static void work(void){ if (!cs_ns) return; double e = now() + cs_ns / 1e9; while (now() < e) ; }
static void *w(void *a){ (void)a; for (long i = 0; i < N; i++) { switch (kind) {
    case 0: atomic_fetch_add(&acounter, 1); work(); break;
    case 1: while (atomic_flag_test_and_set_explicit(&spin, memory_order_acquire)) ; counter++; work(); atomic_flag_clear_explicit(&spin, memory_order_release); break;
    case 2: pthread_mutex_lock(&mx); counter++; work(); pthread_mutex_unlock(&mx); break;
    case 3: sem_wait(&sm); counter++; work(); sem_post(&sm); break; } } return NULL; }
int main(int argc, char **argv){ int T = argc > 1 ? atoi(argv[1]) : 4; N = argc > 2 ? atol(argv[2]) : 200000; cs_ns = argc > 3 ? atol(argv[3]) : 0; sem_init(&sm, 0, 1);
    const char *nm[] = {"atomic add", "spin lock", "mutex", "semaphore"};
    for (kind = 0; kind < 4; kind++) { counter = 0; atomic_store(&acounter, 0); pthread_t t[64]; double w0 = now(), c0 = cpu();
        for (int i = 0; i < T; i++) pthread_create(&t[i], NULL, w, NULL); for (int i = 0; i < T; i++) pthread_join(t[i], NULL);
        double wt = now() - w0, ct = cpu() - c0; long got = kind == 0 ? (long)atomic_load(&acounter) : counter;
        printf("%2d threads cs=%5ldns %-11s wall %7.3f s  %8.1f ns/update  CPU %7.3f s  count %s\n", T, cs_ns, nm[kind], wt, wt / (T * N) * 1e9, ct, got == T * N ? "OK" : "WRONG"); }
    return 0; }
