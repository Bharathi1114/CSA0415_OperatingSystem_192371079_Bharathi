/* Q5: readers-writers with semaphores (readers have preference). 4 readers, 2 writers.
   A writer sets a pair (a,b) to the same value in two steps; a reader must never see a != b. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
static sem_t rw, mutex; static int readcount, a, b; static long bad, reads, writes;
static void *reader(void *x){ (void)x; for (int i = 0; i < 20000; i++) {
    sem_wait(&mutex); if (++readcount == 1) sem_wait(&rw); sem_post(&mutex);
    int ra = a; int rb = b; __atomic_fetch_add(&reads, 1, __ATOMIC_RELAXED); if (ra != rb) __atomic_fetch_add(&bad, 1, __ATOMIC_RELAXED);
    sem_wait(&mutex); if (--readcount == 0) sem_post(&rw); sem_post(&mutex); } return NULL; }
static void *writer(void *x){ (void)x; for (int i = 0; i < 20000; i++) {
    sem_wait(&rw); a++; sched_yield(); b = a; writes++; sem_post(&rw); } return NULL; }
#include <sched.h>
int main(void){ sem_init(&rw, 0, 1); sem_init(&mutex, 0, 1); pthread_t r[4], w[2];
    for (int i = 0; i < 4; i++) pthread_create(&r[i], NULL, reader, NULL); for (int i = 0; i < 2; i++) pthread_create(&w[i], NULL, writer, NULL);
    for (int i = 0; i < 4; i++) pthread_join(r[i], NULL); for (int i = 0; i < 2; i++) pthread_join(w[i], NULL);
    printf("readers-writers: %ld reads, %ld writes, inconsistent reads = %ld, final a=%d b=%d\n", reads, writes, bad, a, b); return 0; }
