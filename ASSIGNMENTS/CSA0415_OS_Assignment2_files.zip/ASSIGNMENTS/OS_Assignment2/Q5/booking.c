/* Q5: railway ticket booking with different lock granularity.
   usage: booking <threads> <global|train|coach|none>
   10 trains x 8 coaches x 10 seats = 800 seats. Each booking attempt picks a random seat, spends 100 us inside the critical
   section on "payment/commit" (simulated by nanosleep) and then sells the seat if it is still free.
   A seat sold more than once is a double sale. Prints throughput and the number of double-sold seats. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#define TR 10
#define CO 8
#define SE 10
#define ATT 300
static int sold[TR][CO][SE]; static pthread_mutex_t gl = PTHREAD_MUTEX_INITIALIZER, tl[TR], cl[TR][CO]; static int gran; /* 0 global 1 train 2 coach 3 none */
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void *agent(void *a){ unsigned seed = (unsigned)(long)a * 7919u + 1; struct timespec d = {0, 100000};
    for (int k = 0; k < ATT; k++) {
        int t = rand_r(&seed) % TR, c = rand_r(&seed) % CO, s = rand_r(&seed) % SE;
        pthread_mutex_t *m = gran == 0 ? &gl : gran == 1 ? &tl[t] : gran == 2 ? &cl[t][c] : NULL;
        if (m) pthread_mutex_lock(m);
        int free_ = (sold[t][c][s] == 0);
        nanosleep(&d, NULL);                                   /* payment / database commit */
        if (free_) sold[t][c][s]++;
        if (m) pthread_mutex_unlock(m);
    } return NULL; }
int main(int argc, char **argv){ int T = argc > 1 ? atoi(argv[1]) : 16; const char *g = argc > 2 ? argv[2] : "global";
    gran = !strcmp(g, "global") ? 0 : !strcmp(g, "train") ? 1 : !strcmp(g, "coach") ? 2 : 3;
    for (int i = 0; i < TR; i++) { pthread_mutex_init(&tl[i], NULL); for (int j = 0; j < CO; j++) pthread_mutex_init(&cl[i][j], NULL); }
    pthread_t th[64]; double t0 = now();
    for (long i = 0; i < T; i++) pthread_create(&th[i], NULL, agent, (void *)i);
    for (int i = 0; i < T; i++) pthread_join(th[i], NULL); double el = now() - t0;
    int dbl = 0, used = 0; for (int t = 0; t < TR; t++) for (int c = 0; c < CO; c++) for (int s = 0; s < SE; s++) { if (sold[t][c][s] > 1) dbl += sold[t][c][s] - 1; if (sold[t][c][s]) used++; }
    printf("%2d threads, %-6s lock: %6.3f s, %8.0f bookings/s, seats sold %3d, double sales %d\n", T, g, el, T * ATT / el, used, dbl); return 0; }
