#!/bin/bash
# Q5: run the completed bounded-buffer program 100 times and count the runs with sum = 210
ok=0; for i in $(seq 1 100); do ./bounded_buffer | grep -q "sum = 210 (expected 210)" && ok=$((ok+1)); done
echo "runs with sum 210: $ok / 100"
