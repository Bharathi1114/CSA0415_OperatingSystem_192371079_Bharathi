# Q5 - Synchronisation
Build: gcc -std=gnu11 -O1 -Wall -Wextra -pthread -o bounded_buffer bounded_buffer.c (same for bb_multi, philosophers, readers_writers, booking, counter_bench); peterson uses -O0
Run: ./bounded_buffer (sum 210) ; bash run100.sh ; ./bb_multi 4 4 sem|monitor|nolock [window] ; ./peterson ; ./philosophers safe|naive ; ./readers_writers ; ./booking 16 global|train|coach|none ; ./counter_bench 16 250000 0
Result files: run100_output.txt, bb_multi_output.txt, peterson_output.txt, classic_output.txt, booking_output.txt, counter_output.txt
