/* Q5: bounded buffer with P producers and C consumers, to test "every item is consumed exactly once".
   usage: bb_multi <P> <C> <mode> [window]   mode = sem (semaphores + mutex) | monitor (mutex + condition variables) | nolock (semaphores, mutex removed)
   Each producer makes PER items with unique ids; a seen[] array counts how often each id is consumed. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sched.h>
#include <pthread.h>
#include <semaphore.h>
#define SIZE 5
#define PER 20000
static int buffer[SIZE], in, out, count; static sem_t empty, full;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER; static pthread_cond_t not_full = PTHREAD_COND_INITIALIZER, not_empty = PTHREAD_COND_INITIALIZER;
static int P, C, mode, window; /* 0 sem 1 monitor 2 nolock; window = force a thread switch inside the unprotected section */
static int *seen; static long consumed_total;
static void put(int item){
    if (mode == 1) { pthread_mutex_lock(&lock); while (count == SIZE) pthread_cond_wait(&not_full, &lock); buffer[in] = item; in = (in + 1) % SIZE; count++; pthread_cond_signal(&not_empty); pthread_mutex_unlock(&lock); return; }
    sem_wait(&empty); if (mode == 0) pthread_mutex_lock(&lock);
    { int slot = in; if (window && mode == 2) sched_yield(); buffer[slot] = item; in = (slot + 1) % SIZE; }
    if (mode == 0) pthread_mutex_unlock(&lock); sem_post(&full);
}
static int take(void){
    int item;
    if (mode == 1) { pthread_mutex_lock(&lock); while (count == 0) pthread_cond_wait(&not_empty, &lock); item = buffer[out]; out = (out + 1) % SIZE; count--; pthread_cond_signal(&not_full); pthread_mutex_unlock(&lock); return item; }
    sem_wait(&full); if (mode == 0) pthread_mutex_lock(&lock);
    { int slot = out; if (window && mode == 2) sched_yield(); item = buffer[slot]; out = (slot + 1) % SIZE; }
    if (mode == 0) pthread_mutex_unlock(&lock); sem_post(&empty); return item;
}
static void *producer(void *a){ long id = (long)a; for (int k = 0; k < PER; k++) put((int)(id * PER + k)); return NULL; }
static void *consumer(void *a){ int share = (int)(long)a; for (int k = 0; k < share; k++) { int it = take(); __atomic_fetch_add(&seen[it], 1, __ATOMIC_RELAXED); __atomic_fetch_add(&consumed_total, 1, __ATOMIC_RELAXED); } return NULL; }
int main(int argc, char **argv)
{
    P = argc > 1 ? atoi(argv[1]) : 1; C = argc > 2 ? atoi(argv[2]) : 1; const char *m = argc > 3 ? argv[3] : "sem"; window = argc > 4;
    mode = !strcmp(m, "monitor") ? 1 : !strcmp(m, "nolock") ? 2 : 0;
    long total = (long)P * PER; seen = calloc(total, sizeof(int));
    sem_init(&empty, 0, SIZE); sem_init(&full, 0, 0);
    pthread_t pt[64], ct[64];
    for (int i = 0; i < C; i++) pthread_create(&ct[i], NULL, consumer, (void *)(long)(total / C + (i == C - 1 ? total % C : 0)));
    for (long i = 0; i < P; i++) pthread_create(&pt[i], NULL, producer, (void *)i);
    for (int i = 0; i < P; i++) pthread_join(pt[i], NULL);
    for (int i = 0; i < C; i++) pthread_join(ct[i], NULL);
    long missing = 0, dup = 0; for (long i = 0; i < total; i++) { if (seen[i] == 0) missing++; else if (seen[i] > 1) dup += seen[i] - 1; }
    printf("%d producer(s), %d consumer(s), mode %-7s: produced %ld, consumed %ld, missing %ld, duplicated %ld -> %s\n",
           P, C, m, total, consumed_total, missing, dup, (missing == 0 && dup == 0) ? "exactly once" : "BROKEN");
    return 0;
}
