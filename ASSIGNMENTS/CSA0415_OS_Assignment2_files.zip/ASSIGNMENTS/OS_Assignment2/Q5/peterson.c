/* Q5: Peterson's solution for two threads protecting a shared counter.
   Default build uses C11 sequentially consistent atomics (correct on modern CPUs).
   Build with -DRELAXED to use plain volatile variables: the textbook code, which is NOT safe on modern processors
   because the CPU may let the store to flag[i] be delayed past the load of flag[j] (store-load reordering).
   Failure needs two CPUs; this machine has one, so the relaxed version cannot be shown failing here. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdatomic.h>
#ifdef RELAXED
 static volatile int flag[2], turn;
 #define SET(x,v) ((x)=(v))
 #define GET(x)   (x)
#else
 static atomic_int flag[2], turn;
 #define SET(x,v) atomic_store(&(x),(v))
 #define GET(x)   atomic_load(&(x))
#endif
static long counter; static long N = 20000;   /* kept small: on one CPU a spinning thread burns its whole time slice */
static void *w(void *a){ int i = (int)(long)a, j = 1 - i;
    for (long k = 0; k < N; k++) {
        SET(flag[i], 1); SET(turn, j);                        /* I want to enter; you go first */
        while (GET(flag[j]) && GET(turn) == j) ;               /* busy wait */
        counter++;                                             /* critical section */
        SET(flag[i], 0);                                       /* exit section */
    } return NULL; }
int main(int argc, char **argv){ if (argc > 1) N = atol(argv[1]); pthread_t t0, t1; pthread_create(&t0, NULL, w, (void *)0L); pthread_create(&t1, NULL, w, (void *)1L);
    pthread_join(t0, NULL); pthread_join(t1, NULL);
    printf("Peterson (%s): counter = %ld, expected %ld -> %s\n",
#ifdef RELAXED
 "volatile, textbook",
#else
 "seq_cst atomics",
#endif
    counter, 2 * N, counter == 2 * N ? "mutual exclusion held" : "VIOLATED"); return 0; }
