# Q6 - Deadlock handling and the Banker's algorithm
Build: gcc -std=c11 -Wall -Wextra -o banker banker.c ; gcc -std=c11 -O1 -o banker_bench banker_bench.c ; deadlock_demo needs -pthread
Run: ./banker (matches expected output) ; ./banker_bench ; ./deadlock_demo cyclic ; ./deadlock_demo ordered
Prediction before measuring: O(m n^2). Measured: comparisons exactly m*n^2/2 in the worst case; time x82 for 10x more processes (100x predicted).
