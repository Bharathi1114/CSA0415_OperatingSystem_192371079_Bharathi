/* Q6 D/E: running time of the Banker's safety algorithm versus n processes and m resource types.
   The state is built for the WORST CASE: process i can only finish after process i+1 (need = 1 unit of resources 0..m-2 and n-i units of the LAST
   resource, alloc = 1 each, avail = 1; every failed check therefore compares all m values), so each pass over the processes finishes just one process: n passes of up to n checks of m values. 
   Prediction made before measuring: T(n, m) = O(m * n^2): x10 processes -> about x100 time; x4 resource types -> about x4 time. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static int safe(int n, int m, const int *avail, const int *maxm, const int *alloc, int *seq, long *checks)
{
    int *work = malloc(m * sizeof(int)), *finish = calloc(n, sizeof(int)), count = 0; memcpy(work, avail, m * sizeof(int)); long c = 0;
    while (count < n) { int found = 0;
        for (int p = 0; p < n; p++) { if (finish[p]) continue;
            int can = 1; for (int r = 0; r < m; r++) { c++; if (maxm[p*m+r] - alloc[p*m+r] > work[r]) { can = 0; break; } }
            if (can) { for (int r = 0; r < m; r++) work[r] += alloc[p*m+r]; finish[p] = 1; seq[count++] = p; found = 1; } }
        if (!found) { free(work); free(finish); *checks = c; return 0; } }
    free(work); free(finish); *checks = c; return 1; }
int main(void)
{
    int ns[] = {10, 100, 1000, 3000, 10000}, ms[] = {3, 12};
    printf("%7s %3s %12s %14s %12s\n", "n", "m", "time (ms)", "comparisons", "time/n^2 (ns)");
    for (int mi = 0; mi < 2; mi++) for (int k = 0; k < 5; k++) { int n = ns[k], m = ms[mi]; if (mi == 1 && n > 1000) continue;
        int *avail = malloc(m*sizeof(int)), *maxm = malloc((size_t)n*m*sizeof(int)), *alloc = malloc((size_t)n*m*sizeof(int)), *seq = malloc(n*sizeof(int));
        for (int r = 0; r < m; r++) avail[r] = 1;
        for (int p = 0; p < n; p++) for (int r = 0; r < m; r++) { alloc[p*m+r] = 1; maxm[p*m+r] = 1 + (r == m - 1 ? n - p : 1); }
        long checks; int reps = 0; double t0 = now(), el; do { safe(n, m, avail, maxm, alloc, seq, &checks); reps++; el = now() - t0; } while (el < 0.3);
        double per = el / reps; int ok = safe(n, m, avail, maxm, alloc, seq, &checks);
        printf("%7d %3d %12.4f %14ld %12.2f %s\n", n, m, per * 1e3, checks, per / ((double)n * n) * 1e9, ok && seq[0] == n - 1 ? "" : "(unexpected result)");
        free(avail); free(maxm); free(alloc); free(seq); }
    return 0;
}
