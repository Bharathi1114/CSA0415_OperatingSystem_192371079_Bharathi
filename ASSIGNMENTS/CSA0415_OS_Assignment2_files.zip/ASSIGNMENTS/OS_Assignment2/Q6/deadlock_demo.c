/* Q6 A/B: three jobs need two of {GPU, LICENCE, STORAGE} at once. usage: deadlock_demo cyclic | ordered
   cyclic : J1 takes GPU then LICENCE, J2 takes LICENCE then STORAGE, J3 takes STORAGE then GPU -> circular wait.
   ordered: every job takes resources in one global order (GPU < LICENCE < STORAGE) -> circular wait is impossible (prevention). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
static pthread_mutex_t res[3] = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER};
static const char *rn[3] = {"GPU", "LICENCE", "STORAGE"}; static int ordered, finished, stuck;
static void *job(void *a){ int j = (int)(long)a, first = j, second = (j + 1) % 3;
    if (ordered && first > second) { int t = first; first = second; second = t; }   /* take the lower-numbered resource first */
    pthread_mutex_lock(&res[first]); printf("J%d holds %s\n", j + 1, rn[first]); fflush(stdout); usleep(100000);
    struct timespec dl; clock_gettime(CLOCK_REALTIME, &dl); dl.tv_sec += 1;
    if (pthread_mutex_timedlock(&res[second], &dl) != 0) { printf("J%d waits for %s forever (timed out after 1 s) -> DEADLOCK\n", j + 1, rn[second]); stuck++; pthread_mutex_unlock(&res[first]); return NULL; }
    printf("J%d holds %s and %s, runs, releases\n", j + 1, rn[first], rn[second]); finished++;
    pthread_mutex_unlock(&res[second]); pthread_mutex_unlock(&res[first]); return NULL; }
int main(int argc, char **argv){ ordered = argc > 1 && !strcmp(argv[1], "ordered"); pthread_t t[3];
    for (long i = 0; i < 3; i++) pthread_create(&t[i], NULL, job, (void *)i); for (int i = 0; i < 3; i++) pthread_join(t[i], NULL);
    printf("%s: %d jobs finished, %d stuck\n", ordered ? "ordered" : "cyclic", finished, stuck); return 0; }
