#!/bin/bash
# Q4: transfer 1, 10 and 100 MB with each method; median of 3 runs (time in seconds).
printf "%-18s %10s %10s %10s\n" method "1 MB" "10 MB" "100 MB"
row(){ label="$1"; shift; printf "%-18s" "$label"
  for mb in 1 10 100; do
    t=$(for i in 1 2 3; do ./ipc_bench "$1" $mb ${2:-} | awk '{print $7" "$NF}'; done | sort -n | sed -n 2p)
    printf " %6s s%s" "${t% *}" "$([ "${t#* }" = OK ] && echo ' ' || echo '!')"
  done; echo; }
row "pipe (64 KB chunk)" pipe 65536
row "pipe (4 KB chunk)"  pipe 4096
row "shared memory+sem"  shm 65536
row "message queue 4 KB" mq 4096
echo "(a '!' after a time would mean a checksum mismatch; none expected)"
