/* Q4 alternative-concept test: n small readings (one int each) through a pipe versus shared memory + semaphore.
   usage: ipc_small <n>.  Shows the cost per reading: 2 system calls and 2 kernel copies (pipe) versus semaphore operations only. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
#define SLOTS 64
typedef struct { sem_t empty, full; int buf[SLOTS]; long sum; } Ctl;
int main(int argc, char **argv)
{
    long n = argc > 1 ? atol(argv[1]) : 100000; long expect = n * (n + 1) / 2;
    int fd[2]; if (pipe(fd)) return 1; long *res = mmap(0, 8, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
    double t0 = now(); pid_t p = fork();
    if (p == 0) { close(fd[1]); int v; long s = 0; while (read(fd[0], &v, sizeof v) == (ssize_t)sizeof v) s += v; *res = s; _exit(0); }
    close(fd[0]); for (int i = 1; i <= n; i++) if (write(fd[1], &i, sizeof i) < 0) return 1; close(fd[1]); waitpid(p, 0, 0);
    double tp = now() - t0; int ok1 = *res == expect;
    Ctl *c = mmap(0, sizeof *c, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0); sem_init(&c->empty, 1, SLOTS); sem_init(&c->full, 1, 0);
    t0 = now(); p = fork();
    if (p == 0) { long s = 0; for (long k = 0, i = 0; k < n; k++, i = (i + 1) % SLOTS) { sem_wait(&c->full); s += c->buf[i]; sem_post(&c->empty); } c->sum = s; _exit(0); }
    for (long k = 1, i = 0; k <= n; k++, i = (i + 1) % SLOTS) { sem_wait(&c->empty); c->buf[i] = (int)k; sem_post(&c->full); }
    waitpid(p, 0, 0); double ts = now() - t0; int ok2 = c->sum == expect;
    printf("n = %ld readings\npipe              : %.4f s total, %.2f us per reading, sum %s\nshared mem + sems : %.4f s total, %.2f us per reading, sum %s\n",
           n, tp, tp / n * 1e6, ok1 ? "OK" : "WRONG", ts, ts / n * 1e6, ok2 ? "OK" : "WRONG");
    return 0;
}
