# Q4 - Inter-process communication
Build: gcc -std=gnu11 -O1 -Wall -Wextra -pthread -o pipe_sensor pipe_sensor.c -lrt (same for pipe_noclose, ipc_bench, ipc_small)
Run: ./pipe_sensor (matches expected output) ; timeout 3 ./pipe_noclose (hangs, exit 124) ; bash bench_ipc.sh ; ./ipc_small 100000
Methods: pipe, POSIX shared memory ring with semaphores, POSIX message queue. All checksums matched.
