/* Q4: transfer MB megabytes from a producer process to a consumer process with
   pipe | shm (POSIX shared memory ring + semaphores) | mq (POSIX message queue).
   usage: ipc_bench <method> <MB> [chunk]. The consumer sums every 8 bytes it receives; the producer computes the same sum,
   so a matching checksum proves that nothing was lost or duplicated. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <semaphore.h>
#include <mqueue.h>
#include <sys/mman.h>
#include <sys/wait.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static uint64_t sum8(const void *p, size_t n){ const uint64_t *q = p; uint64_t s = 0; for (size_t i = 0; i < n/8; i++) s += q[i]; return s; }
static void fill(void *p, size_t n, uint64_t seed){ uint64_t *q = p; for (size_t i = 0; i < n/8; i++) q[i] = seed + i * 2654435761u; }
#define SLOTS 4
typedef struct { sem_t empty, full; int len[SLOTS]; uint64_t consumer_sum; } Ctl;
int main(int argc, char **argv)
{
    const char *m = argc > 1 ? argv[1] : "pipe"; size_t total = (size_t)(argc > 2 ? atol(argv[2]) : 10) << 20;
    size_t chunk = argc > 3 ? (size_t)atol(argv[3]) : (!strcmp(m, "mq") ? 4096 : 65536);
    uint64_t psum = 0; double t0, t1;
    if (!strcmp(m, "pipe")) {
        int fd[2]; if (pipe(fd)) return 1; uint64_t *shared = mmap(0, 8, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
        t0 = now(); pid_t p = fork();
        if (p == 0) { close(fd[1]); char *b = malloc(chunk); uint64_t s = 0; ssize_t r; while ((r = read(fd[0], b, chunk)) > 0) s += sum8(b, r); *shared = s; _exit(0); }
        close(fd[0]); char *b = malloc(chunk); for (size_t off = 0; off < total; off += chunk) { fill(b, chunk, off); psum += sum8(b, chunk); size_t w = 0; while (w < chunk) { ssize_t r = write(fd[1], b + w, chunk - w); if (r < 0) return 1; w += r; } }
        close(fd[1]); waitpid(p, 0, 0); t1 = now();
        printf("%-5s %4zu MB chunk %6zu : %8.4f s  %8.1f MB/s  checksum %s\n", m, total>>20, chunk, t1-t0, (total>>20)/(t1-t0), *shared == psum ? "OK" : "MISMATCH");
    } else if (!strcmp(m, "shm")) {
        size_t sz = sizeof(Ctl) + SLOTS * chunk; Ctl *c = mmap(0, sz, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0); char *ring = (char *)(c + 1);
        sem_init(&c->empty, 1, SLOTS); sem_init(&c->full, 1, 0);
        t0 = now(); pid_t p = fork();
        if (p == 0) { uint64_t s = 0; for (int i = 0;; i = (i + 1) % SLOTS) { sem_wait(&c->full); if (c->len[i] == 0) break; s += sum8(ring + i * chunk, c->len[i]); sem_post(&c->empty); } c->consumer_sum = s; _exit(0); }
        int i = 0; for (size_t off = 0; off < total; off += chunk, i = (i + 1) % SLOTS) { sem_wait(&c->empty); fill(ring + i * chunk, chunk, off); psum += sum8(ring + i * chunk, chunk); c->len[i] = (int)chunk; sem_post(&c->full); }
        sem_wait(&c->empty); c->len[i] = 0; sem_post(&c->full);            /* end marker */
        waitpid(p, 0, 0); t1 = now();
        printf("%-5s %4zu MB chunk %6zu : %8.4f s  %8.1f MB/s  checksum %s\n", m, total>>20, chunk, t1-t0, (total>>20)/(t1-t0), c->consumer_sum == psum ? "OK" : "MISMATCH");
    } else {
        struct mq_attr at = {0, 10, (long)chunk, 0}; mq_unlink("/ipcbench"); mqd_t q = mq_open("/ipcbench", O_CREAT|O_RDWR, 0600, &at);
        if (q == (mqd_t)-1) { perror("mq_open"); return 1; }
        uint64_t *shared = mmap(0, 8, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
        t0 = now(); pid_t p = fork();
        if (p == 0) { char *b = malloc(chunk); uint64_t s = 0; for (;;) { ssize_t r = mq_receive(q, b, chunk, 0); if (r <= 0) break; if (r == 1) break; s += sum8(b, r); } *shared = s; _exit(0); }
        char *b = malloc(chunk); for (size_t off = 0; off < total; off += chunk) { fill(b, chunk, off); psum += sum8(b, chunk); mq_send(q, b, chunk, 0); }
        mq_send(q, "e", 1, 0); waitpid(p, 0, 0); t1 = now(); mq_close(q); mq_unlink("/ipcbench");
        printf("%-5s %4zu MB chunk %6zu : %8.4f s  %8.1f MB/s  checksum %s\n", m, total>>20, chunk, t1-t0, (total>>20)/(t1-t0), *shared == psum ? "OK" : "MISMATCH");
    }
    return 0;
}
