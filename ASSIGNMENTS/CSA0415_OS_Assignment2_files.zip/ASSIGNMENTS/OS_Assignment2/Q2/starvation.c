/* Q2: starvation in priority and SJF scheduling, and how aging removes it.
   A long/low-priority job L arrives at t=0; a stream of short high-priority jobs (burst 2) arrives every 2 ticks
   from t=0 to t=199. Non-preemptive. Aging: effective key = base - waited/step (smaller = better); step 10 for priority, 5 for SJF. */
#include <stdio.h>
#include <string.h>
#define M 200
typedef struct { int arr, burst, key; } J;
static J jobs[M+1];
static int run(int use_aging, int age_every, int *start_L)
{
    int left[M+1]; for(int i=0;i<=M;i++) left[i]=jobs[i].burst;
    int t=0, done=0, total=M+1;
    while(done<total){
        int best=-1,bk=1<<30;
        for(int i=0;i<=M;i++) if(left[i]>0 && jobs[i].arr<=t){
            int k=jobs[i].key; if(use_aging) k -= (t-jobs[i].arr)/age_every;
            if(k<bk){bk=k;best=i;}
        }
        if(best<0){t++;continue;}
        if(best==0 && *start_L<0) *start_L=t;
        t+=left[best]; left[best]=0; done++;
        if(best==0) return t;                    /* L finished */
    }
    return -1;
}
int main(void)
{
    for(int mode=0;mode<2;mode++){                /* 0 = priority, 1 = SJF */
        jobs[0]=(J){0, mode?50:5, mode?50:10};    /* L: SJF key = burst 50; priority key = 10 (low priority) */
        for(int i=1;i<=M;i++) jobs[i]=(J){2*(i-1), 2, mode?2:1};
        for(int ag=0;ag<2;ag++){
            int st=-1; int f=run(ag, mode?5:10, &st);   /* aging step: 1 level per 10 ticks (priority) or 1 burst unit per 5 ticks (SJF) */
            printf("%-9s %-11s : job L waits until t=%3d, finishes at t=%3d\n", mode?"SJF":"Priority", ag?"with aging":"no aging", st, f);
        }
    }
    return 0;
}
