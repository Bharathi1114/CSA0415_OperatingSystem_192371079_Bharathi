/* Q2: scheduling simulator (1 CPU, 1 tick = 1 time unit).
   Algorithms: FCFS, SJF (non-preemptive), SRTF, Priority (non-preemptive, lower number = higher priority),
   Round Robin (quantum q), MLFQ (3 levels, demotion, periodic boost).
   usage: sched_sim A            -> the 4-job set of the assignment, all algorithms + RR quantum study
          sched_sim V            -> video-service set (2 films of 1200 s, 8 thumbnails of 2 s) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXJ 32
#define MAXSEG 20000
typedef struct { const char *name; int arr, burst, prio; } Job;
static Job J[MAXJ]; static int n;
static int fin[MAXJ], first[MAXJ], left[MAXJ];
static int segp[MAXSEG], segs[MAXSEG], sege[MAXSEG], nseg;

static void seg(int p, int s, int e){ if(nseg && segp[nseg-1]==p && sege[nseg-1]==s){sege[nseg-1]=e;return;} segp[nseg]=p;segs[nseg]=s;sege[nseg]=e;nseg++; }
static void reset(void){ nseg=0; for(int i=0;i<n;i++){left[i]=J[i].burst;fin[i]=-1;first[i]=-1;} }
static void touch(int p,int t){ if(first[p]<0) first[p]=t; }

/* generic tick-based engine for the non-RR algorithms: pick(t,cur) returns job to run this tick or -1 */
static int algo_kind; /* 0 FCFS 1 SJF 2 SRTF 3 PRIO */
static int pick(int t, int cur)
{
    if (algo_kind==2 || cur<0 || left[cur]==0) {              /* decision point */
        int best=-1;
        for (int i=0;i<n;i++) if (J[i].arr<=t && left[i]>0) {
            if (best<0) { best=i; continue; }
            int a,b;
            if (algo_kind==0) { a=J[i].arr; b=J[best].arr; }
            else if (algo_kind==1) { a=J[i].burst; b=J[best].burst; }
            else if (algo_kind==2) { a=left[i]; b=left[best]; }
            else { a=J[i].prio; b=J[best].prio; }
            if (a<b) best=i;                                    /* ties: earlier index (earlier arrival order) */
        }
        return best;
    }
    return cur;                                                 /* non-preemptive: keep running */
}
static void run_simple(int kind){
    algo_kind=kind; reset(); int t=0,done=0,cur=-1;
    while(done<n){
        cur=pick(t,cur);
        if(cur<0){t++;continue;}
        touch(cur,t); seg(cur,t,t+1); left[cur]--; t++;
        if(left[cur]==0){fin[cur]=t;done++;}
    }
}
static void run_rr(int q){
    reset(); int queue[100000],head=0,tail=0,added[MAXJ]={0},t=0,done=0;
    for(int i=0;i<n;i++) if(J[i].arr<=0){queue[tail++]=i;added[i]=1;}
    while(done<n){
        if(head==tail){ t++; for(int i=0;i<n;i++) if(!added[i]&&J[i].arr<=t){queue[tail++]=i;added[i]=1;} continue; }
        int p=queue[head++]; int run=q<left[p]?q:left[p]; touch(p,t);
        seg(p,t,t+run); t+=run; left[p]-=run;
        for(int i=0;i<n;i++) if(!added[i]&&J[i].arr<=t){queue[tail++]=i;added[i]=1;}
        if(left[p]>0) queue[tail++]=p; else {fin[p]=t;done++;}
    }
}
/* MLFQ: levels with quanta Q[0..2]; a job that uses its whole quantum drops one level; all jobs boosted every `boost` ticks */
static void run_mlfq(int q0,int q1,int q2,int boost){
    reset(); int Q[3]={q0,q1,q2}; int lvl[MAXJ]; int inq[MAXJ]; static int qu[3][100000]; int hd[3]={0},tl[3]={0};
    for(int i=0;i<n;i++){lvl[i]=0;inq[i]=0;}
    int t=0,done=0,cur=-1,used=0;
    while(done<n){
        for(int i=0;i<n;i++) if(!inq[i]&&J[i].arr<=t&&left[i]>0&&i!=cur&&J[i].arr==t){ qu[0][tl[0]++]=i; inq[i]=1; }
        if(boost && t>0 && t%boost==0){            /* priority boost: everybody back to level 0 */
            for(int l=1;l<3;l++) while(hd[l]<tl[l]){int p=qu[l][hd[l]++]; lvl[p]=0; qu[0][tl[0]++]=p;}
            if(cur>=0){ lvl[cur]=0; }
        }
        if(cur>=0){ int hi=-1; for(int l=0;l<lvl[cur];l++) if(hd[l]<tl[l]){hi=l;break;}
            if(hi>=0){ qu[lvl[cur]][tl[lvl[cur]]++]=cur; cur=-1; } }       /* preempted by a higher queue */
        if(cur<0){ int l; for(l=0;l<3;l++) if(hd[l]<tl[l]) break; if(l==3){t++;continue;} cur=qu[l][hd[l]++]; used=0; }
        touch(cur,t); seg(cur,t,t+1); left[cur]--; used++; t++;
        if(left[cur]==0){fin[cur]=t;done++;cur=-1;continue;}
        if(used>=Q[lvl[cur]]){ if(lvl[cur]<2) lvl[cur]++; qu[lvl[cur]][tl[lvl[cur]]++]=cur; cur=-1; }
    }
}
static void report(const char *title, int verbose, double *awt_all, int group_split)
{
    double tt=0,tw=0,tr=0,ws=0,wl=0; int ns=0,nl=0;
    if(verbose){ printf("%s\nGantt:",title); int shown=0; for(int i=0;i<nseg;i++){ if(shown++<40) printf(" %s(%d-%d)",J[segp[i]].name,segs[i],sege[i]); } if(nseg>40) printf(" ... (%d segments)",nseg); printf("\n"); printf("Process  CT  TAT  WT  RT\n"); }
    for(int i=0;i<n;i++){ int tat=fin[i]-J[i].arr, wt=tat-J[i].burst, rt=first[i]-J[i].arr; tt+=tat;tw+=wt;tr+=rt;
        if(group_split){ if(J[i].burst<=10){ws+=wt;ns++;}else{wl+=wt;nl++;} }
        if(verbose && n<=10) printf("%-7s %3d %4d %3d %3d\n",J[i].name,fin[i],tat,wt,rt); }
    printf("%-26s avg TAT %8.2f  avg WT %8.2f  avg RT %8.2f  context switches %d", verbose?"":title, tt/n,tw/n,tr/n, nseg>0?nseg-1:0);
    if(group_split) printf("  | short jobs WT %.1f, long jobs WT %.1f", ns?ws/ns:0, nl?wl/nl:0);
    printf("\n"); if(awt_all)*awt_all=tw/n;
}
int main(int argc,char**argv)
{
    char set = argc>1?argv[1][0]:'A';
    if(set=='A'){
        Job a[]={{"P1",0,8,3},{"P2",1,4,1},{"P3",2,9,4},{"P4",3,5,2}}; n=4; memcpy(J,a,sizeof a);
        printf("Jobs: P1(arr 0,burst 8,prio 3) P2(1,4,1) P3(2,9,4) P4(3,5,2)   [priority: lower number = higher]\n\n");
        run_simple(0); report("FCFS",1,0,0); printf("\n");
        run_simple(1); report("SJF (non-preemptive)",1,0,0); printf("\n");
        run_simple(2); report("SRTF (preemptive SJF)",1,0,0); printf("\n");
        run_simple(3); report("Priority (non-preemptive)",1,0,0); printf("\n");
        run_rr(3); report("Round Robin q=3",1,0,0); printf("\nRound Robin quantum study:\n");
        int qs[]={1,3,5,20}; for(int i=0;i<4;i++){ char t[40]; snprintf(t,sizeof t,"RR q=%d",qs[i]); run_rr(qs[i]); report(t,0,0,0); }
    } else {
        n=0; J[n++]=(Job){"Film1",0,1200,2}; J[n++]=(Job){"Film2",0,1200,2};
        static char nm[8][12]; for(int i=0;i<8;i++){ snprintf(nm[i],12,"Thumb%d",i+1); J[n++]=(Job){nm[i],10*(i+1),2,1}; }
        printf("Video service: Film1, Film2 (1200 s each, arrive 0); Thumb1..8 (2 s each, arrive every 10 s from t=10)\n");
        printf("\n");
        run_simple(0); report("FCFS",0,0,1);
        run_simple(1); report("SJF (non-preemptive)",0,0,1);
        run_simple(2); report("SRTF",0,0,1);
        run_simple(3); report("Priority (thumbs first)",0,0,1);
        run_rr(10); report("RR q=10",0,0,1);
        run_rr(100); report("RR q=100",0,0,1);
        run_mlfq(4,16,64,600); report("MLFQ (4,16,64; boost 600)",0,0,1);
    }
    return 0;
}
