# Q2 - CPU scheduling
Build: gcc -std=c11 -O1 -Wall -Wextra -o rr_complete rr_complete.c (quantum with -DQUANTUM=1 or 20) ; same flags for sched_sim, starvation, decision_cost
Run: ./rr_complete (matches expected output: avg TAT 20.00, avg WT 13.50) ; ./sched_sim A ; ./sched_sim V ; ./starvation ; ./decision_cost
Result files: rr_q1/q3/q20_output.txt, sim_A_output.txt, sim_V_output.txt, starvation_output.txt, decision_output.txt
