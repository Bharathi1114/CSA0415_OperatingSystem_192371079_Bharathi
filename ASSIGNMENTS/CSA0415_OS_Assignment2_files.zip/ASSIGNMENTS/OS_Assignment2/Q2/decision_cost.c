#define _POSIX_C_SOURCE 200809L
/* Q2: cost of one scheduling decision versus the number n of ready jobs.
   SJF must find the shortest job among n (O(n) scan); Round Robin / MLFQ take the head of a queue (O(1)). */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
int main(void)
{
    int ns[] = {10, 100, 1000, 10000, 100000};
    printf("%8s %18s %22s\n", "n", "SJF scan (ns)", "queue head, RR/MLFQ (ns)");
    for (int k = 0; k < 5; k++) {
        int n = ns[k]; int *burst = malloc(n*sizeof(int)); int *q = malloc(n*sizeof(int));
        for (int i = 0; i < n; i++) { burst[i] = rand() % 1000 + 1; q[i] = i; }
        long reps = 200000000L / n; if (reps > 2000000) reps = 2000000; if (reps < 200) reps = 200;
        volatile long sink = 0; double t0 = now();
        for (long r = 0; r < reps; r++) { int best = 0; for (int i = 1; i < n; i++) if (burst[i] < burst[best]) best = i; sink += best; }
        double t1 = now();
        int head = 0; for (long r = 0; r < reps; r++) { sink += q[head]; head = (head + 1) % n; }
        double t2 = now();
        printf("%8d %18.1f %22.2f\n", n, (t1-t0)/reps*1e9, (t2-t1)/reps*1e9);
        free(burst); free(q);
    }
    return 0;
}
