# CSA0415 Operating Systems - Assignment 2 (CO2)

- Name: Bharathi
- Register number: 192371079
- Course: CSA0415 Operating Systems, SIMATS Engineering
- Compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0
- Linux: Ubuntu 24.04.5 LTS, kernel 6.18.44 (virtual machine, 1 vCPU, about 4 GB RAM); strace/ps from the same system
- Build everything: `bash build.sh` (exact gcc commands are inside; typical: `gcc -std=gnu11 -O1 -Wall -Wextra -pthread -o name name.c`)

## Folders
| Folder | Question | Main programs |
|---|---|---|
| Q1 | Processes and process states | fork_states, proc_scale, ctx_switch, crash_demo |
| Q2 | CPU scheduling | rr_complete (completed code), sched_sim, starvation, decision_cost |
| Q3 | Threads | plate_reader, race_demo |
| Q4 | Inter-process communication | pipe_sensor (completed code), pipe_noclose, ipc_bench, ipc_small |
| Q5 | Synchronisation | bounded_buffer (completed code), bb_multi, peterson, philosophers, readers_writers, booking, counter_bench |
| Q6 | Deadlock and Banker's algorithm | banker (completed code), banker_bench, deadlock_demo |

Every folder has a README with the exact run commands, the captured outputs (`*_output.txt`) and a `screenshots/` folder rendered from those outputs.

## Notes
- The machine used has a single CPU. Speed-ups of CPU-bound code with more threads therefore stay near 1.0 here; re-run Q3 on a multi-core computer to see the scaling. Race conditions that need two CPUs are shown with a forced thread switch (`window` option), which is stated wherever it is used.
- Timing numbers depend on the machine; counts of system calls, comparisons and scheduling results do not.
