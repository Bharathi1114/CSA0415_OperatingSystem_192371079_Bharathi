/* Q3: shared counter updated by several threads with no protection, with a mutex, and with an atomic add.
   usage: race_demo <threads> <increments each> [window]
   With "window" a sched_yield() is placed between the read and the write of the counter, which forces the same
   interleaving that two CPUs produce naturally (this machine has only one CPU, so lost updates are rare without it). */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <pthread.h>
#include <stdatomic.h>
static volatile long plain; static long locked; static atomic_long atom;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static long N; static int window;
static void *w(void *a){ (void)a;
    for (long i = 0; i < N; i++) {
        long v = plain; if (window && (i % 1000) == 0) sched_yield(); plain = v + 1;      /* unprotected read-modify-write */
        pthread_mutex_lock(&m); locked++; pthread_mutex_unlock(&m);
        atomic_fetch_add(&atom, 1);
    } return NULL; }
int main(int argc, char **argv)
{
    int T = argc > 1 ? atoi(argv[1]) : 2; N = argc > 2 ? atol(argv[2]) : 1000000; window = argc > 3;
    pthread_t t[64]; for (int i = 0; i < T; i++) pthread_create(&t[i], NULL, w, NULL);
    for (int i = 0; i < T; i++) pthread_join(t[i], NULL);
    long expect = (long)T * N;
    printf("threads=%d expected=%ld | unprotected=%ld (lost %ld) | mutex=%ld | atomic=%ld\n", T, expect, plain, expect - plain, locked, (long)atom);
    return 0;
}
