#!/bin/bash
# Q3: median of 3 runs for each model/worker count and workload; speed-up relative to the sequential version.
echo "CPUs available: $(nproc)"
med(){ for i in 1 2 3; do ./plate_reader "$@"; done | sort -n | sed -n 2p; }
for wl in cpu io; do
  echo; echo "workload: $wl"
  printf "%-22s %9s %9s %8s\n" model "time(s)" "speed-up" plates
  read bt bp <<< "$(med seq 1 $wl)"
  printf "%-22s %9s %9s %8s\n" "sequential" "$bt" "1.00" "$bp"
  for cfg in "thread 4" "thread 8" "thread 16" "thread 64" "proc 4" "proc 8" "proc 16"; do
    read t p <<< "$(med $cfg $wl)"
    set -- $cfg
    case "$1 $2" in
      "thread 64") label="64 threads (1 per camera)";;
      thread*)     label="thread pool of $2";;
      *)           label="$2 processes";;
    esac
    printf "%-26s %9s %9.2f %8s\n" "$label" "$t" "$(echo "$bt / $t" | bc -l)" "$p"
  done
done
