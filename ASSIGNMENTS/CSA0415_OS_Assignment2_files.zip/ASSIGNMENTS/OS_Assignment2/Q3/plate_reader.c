/* Q3: traffic-camera number-plate reader. 64 cameras x 4 frames each.
   usage: plate_reader <model> <workers> <workload>
     model    : seq | thread (workers threads pull cameras from a shared counter) | proc (workers forked processes)
     workload : cpu (recognition only) | io (3 ms wait for the frame + recognition)
   "one thread per camera" = thread with workers=64; pools = thread with 4, 8, 16.
   Prints wall time and the total number of plates found (must be identical for every model). */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <sys/wait.h>
#define CAMERAS 64
#define FRAMES 4
#define ITER 2500000UL
static int io_mode;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void msleep(int ms){struct timespec t={0,ms*1000000L};nanosleep(&t,NULL);}
static long recognise(int cam, int frame)           /* CPU-bound "plate recognition"; returns 1 if a plate is found */
{
    unsigned long x = 88172645463325252UL ^ (unsigned long)(cam * 131 + frame);
    for (unsigned long i = 0; i < ITER; i++) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; }
    return (x % 3) == 0;
}
static long do_camera(int cam){ long found = 0; for (int f = 0; f < FRAMES; f++) { if (io_mode) msleep(3); found += recognise(cam, f); } return found; }

static atomic_int next_cam; static atomic_long total_found;
static void *worker(void *a){ (void)a; long mine = 0; int c; while ((c = atomic_fetch_add(&next_cam, 1)) < CAMERAS) mine += do_camera(c); atomic_fetch_add(&total_found, mine); return NULL; }

int main(int argc, char **argv)
{
    const char *model = argc > 1 ? argv[1] : "seq"; int w = argc > 2 ? atoi(argv[2]) : 1;
    io_mode = argc > 3 && !strcmp(argv[3], "io");
    double t0 = now(); long found = 0;
    if (!strcmp(model, "seq")) { for (int c = 0; c < CAMERAS; c++) found += do_camera(c); }
    else if (!strcmp(model, "thread")) {
        pthread_t *t = malloc(w * sizeof *t);
        for (int i = 0; i < w; i++) pthread_create(&t[i], NULL, worker, NULL);
        for (int i = 0; i < w; i++) pthread_join(t[i], NULL);
        found = atomic_load(&total_found); free(t);
    } else {                                           /* processes: results come back through pipes (IPC) */
        int (*fd)[2] = malloc(w * sizeof *fd);
        for (int i = 0; i < w; i++) {
            pipe(fd[i]);
            if (fork() == 0) { long mine = 0; for (int c = i; c < CAMERAS; c += w) mine += do_camera(c); if (write(fd[i][1], &mine, sizeof mine) < 0) _exit(1); _exit(0); }
        }
        for (int i = 0; i < w; i++) { long v = 0; if (read(fd[i][0], &v, sizeof v) == (ssize_t)sizeof v) found += v; wait(NULL); }
        free(fd);
    }
    printf("%.4f %ld\n", now() - t0, found);
    return 0;
}
