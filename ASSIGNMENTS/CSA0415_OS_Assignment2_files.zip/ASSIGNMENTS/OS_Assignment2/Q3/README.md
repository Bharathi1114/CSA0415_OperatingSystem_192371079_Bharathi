# Q3 - Threads
Build: gcc -std=gnu11 -O1 -Wall -Wextra -pthread -o plate_reader plate_reader.c ; race_demo uses -O0
Run: bash bench_plate.sh ; ./race_demo 2 2000000 ; ./race_demo 4 200000 window
Note: this machine has 1 CPU, so the CPU-bound speed-up is about 1.0; the I/O+CPU workload reaches about 1.8. Re-run on a multi-core computer for the CPU-bound scaling.
