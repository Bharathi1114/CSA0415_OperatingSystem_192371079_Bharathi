#!/bin/bash
# Build every program of Assignment 2 with the exact commands used for the report.  Usage: bash build.sh
set -e
G="gcc -std=gnu11 -O1 -Wall -Wextra -pthread"
cd "$(dirname "$0")"
( cd Q1; for f in fork_states proc_scale ctx_switch crash_demo; do $G -o $f $f.c; done )
( cd Q2; C="gcc -std=c11 -O1 -Wall -Wextra"; for f in sched_sim starvation; do $C -o $f $f.c; done
  $C -D_POSIX_C_SOURCE=200809L -o decision_cost decision_cost.c
  for q in 1 3 20; do $C -DQUANTUM=$q -o rr_q$q rr_complete.c; done; $C -o rr_complete rr_complete.c )
( cd Q3; $G -o plate_reader plate_reader.c; gcc -std=gnu11 -O0 -Wall -Wextra -pthread -o race_demo race_demo.c )
( cd Q4; for f in pipe_sensor pipe_noclose ipc_bench ipc_small; do $G -o $f $f.c -lrt; done )
( cd Q5; for f in bounded_buffer bb_multi philosophers readers_writers booking counter_bench; do $G -o $f $f.c; done
  gcc -std=gnu11 -O0 -Wall -Wextra -pthread -o peterson peterson.c
  gcc -std=gnu11 -O0 -DRELAXED -Wall -Wextra -pthread -o peterson_relaxed peterson.c )
( cd Q6; gcc -std=c11 -Wall -Wextra -o banker banker.c; gcc -std=c11 -O1 -Wall -Wextra -o banker_bench banker_bench.c
  $G -o deadlock_demo deadlock_demo.c )
echo "all programs built"
